#include "p2_v2.h"

void p2_v2()
{
	std::cout << "P2_v2 begin:" << std::endl;
	d2_v3();
	d3_v5();
	d4_v7();
	std::cout << "P2_v2 end:" << std::endl;
}

