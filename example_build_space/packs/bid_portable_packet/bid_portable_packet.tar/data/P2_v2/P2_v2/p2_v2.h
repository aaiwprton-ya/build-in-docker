#ifndef P2_V2_H
#define P2_V2_H

#include <iostream>
#include <d2_v3.h>
#include <d3_v5.h>
#include <d4_v7.h>

void p2_v2();

#endif // P2_V2_H
