#include "p2_v2.h"

int main(int argc, char** argv)
{
	p2_v2();
	return 0;
}

