#include "d1_v1.h"

void d1_v1()
{
	std::cout << "D1_v1" << std::endl;
}

