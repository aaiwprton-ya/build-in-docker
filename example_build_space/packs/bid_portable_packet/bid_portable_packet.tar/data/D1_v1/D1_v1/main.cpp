#include "d1_v1.h"

int main(int argc, char** argv)
{
	d1_v1();
	return 0;
}

