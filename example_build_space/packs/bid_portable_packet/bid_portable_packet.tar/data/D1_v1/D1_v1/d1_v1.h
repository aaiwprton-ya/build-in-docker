#ifndef D1_V1_H
#define D1_V1_H

#include <iostream>

void d1_v1();

#endif // D1_V1_H
