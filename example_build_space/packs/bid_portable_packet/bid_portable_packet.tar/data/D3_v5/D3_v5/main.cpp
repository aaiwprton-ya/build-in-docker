#include "d3_v5.h"

int main(int argc, char** argv)
{
	d3_v5();
	return 0;
}

