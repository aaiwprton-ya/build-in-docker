#include "d3_v5.h"

void d3_v5()
{
	std::cout << "D3_v5" << std::endl;
}

