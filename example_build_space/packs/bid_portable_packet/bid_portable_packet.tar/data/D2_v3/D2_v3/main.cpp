#include "d2_v3.h"

int main(int argc, char** argv)
{
	d2_v3();
	return 0;
}

