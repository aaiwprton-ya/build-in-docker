#ifndef D2_V3_H
#define D2_V3_H

#include <iostream>

void d2_v3();

#endif // D2_V3_H
