#include "d2_v3.h"

void d2_v3()
{
	std::cout << "D2_v3" << std::endl;
}

