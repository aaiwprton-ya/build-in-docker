#include "p1_v1.h"

int main(int argc, char** argv)
{
	p1_v1();
	return 0;
}

