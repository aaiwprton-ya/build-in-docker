#ifndef P1_V1_H
#define P1_V1_H

#include <iostream>
#include <d1_v1.h>
#include <d2_v3.h>
#include <d3_v5.h>

void p1_v1();

#endif // P1_V1_H
