#include "p1_v1.h"

void p1_v1()
{
	std::cout << "P1_v1 begin:" << std::endl;
	d1_v1();
	d2_v3();
	d3_v5();
	std::cout << "P1_v1 end:" << std::endl;
}

