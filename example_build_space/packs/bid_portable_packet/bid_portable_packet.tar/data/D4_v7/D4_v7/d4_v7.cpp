#include "d4_v7.h"

void d4_v7()
{
	std::cout << "D4_v7" << std::endl;
}

